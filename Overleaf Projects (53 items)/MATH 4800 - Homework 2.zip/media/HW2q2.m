% Homework 2 Driver Code

% Plot f(x) = cos(3x) + 0.5(x^3)
X = -1:.05:1.5;
f = @(x) cos(3*x) + 0.5*x.^3;
y = f(X);
plot(X,y)
grid on
xlabel('x')
ylabel('f(x)')
a = -1; b = 0;
xc = bisect(f,a,b,1e-6,100)

a = .55; b = 1.05;
xc = bisect(f,a,b,1e-6,100)

a = .7; b = 1.7;
xc = bisect(f,a,b,1e-6,100)
