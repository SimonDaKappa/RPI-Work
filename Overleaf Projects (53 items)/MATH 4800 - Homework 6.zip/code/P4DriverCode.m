[splineX,splineY] = P4Spline(5);
[splineX2,splineY2] = P4Spline(9);