swipl -s part1Tester.pl -t main --quiet > part1Result.txt
swipl -s part2.pl  -t main --quiet -- example1.txt  > part2Result1.txt
